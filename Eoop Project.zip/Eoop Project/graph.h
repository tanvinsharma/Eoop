#ifndef GRAPH_H
#define GRAPH_H
#pragma once
	#include "structure.h"
	#include "backbone.h"
	
	//calculates different parameters of a fanclub
	void graphCompare(FanClubs, FanClubs);
	//prints graph using GNU plot		
	void showgraph();
#endif
