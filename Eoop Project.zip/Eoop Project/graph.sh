#s!/usr/bin/gnuplot -persist


gnuplot > load "graph.gnu"

